var users = {
 
    getAll: function(req, res) {
      var allusers = userList; 
      res.json(allusers);
    },
   
    getOne: function(req, res) {
      var id = req.params.id;
      var user = userList[id]; 
      res.json(user);
    },
   
    create: function(req, res) {
      var newuser = req.body;
      userList.push(newuser); 
      res.json(newuser);
    },
   
    update: function(req, res) {
      var updateUser = req.body;
      var id = req.params.id;
      userList[id] = updateUser 
      res.json(updateUser);
    },
   
    delete: function(req, res) {
      var id = req.params.id;
      userList.splice(id, 1) 
      res.json(true);
    }
  };
   
  var userList = [{
    name: 'user 1',
    id: '1'
  }, {
    name: 'user 2',
    id: '2'
  }, {
    name: 'user 3',
    id: '3'
  }, {
    name: 'user 4',
    id: '4'
  }];
   
  module.exports = users;