var books = {
 
    getAll: function(req, res) {
      var allBooks = bookList; 
      console.log("inAllBooks");
      console.log("id")
      res.json(allBooks);
    },
   
    getOne: function(req, res) {
      var id = req.params.id;
      console.log("id", id);
      var book = bookList[id]; 
      res.json(book);
    },
   
    create: function(req, res) {
      var newBook = req.body;
      bookList.push(newBook);
      res.json(newBook);
    },
   
    update: function(req, res) {
      var updateBook = req.body;
      var id = req.params.id;
      bookList[id] = updateBook 
      res.json(updateBook);
    },
   
    delete: function(req, res) {
      var id = req.params.id;
      bookList.splice(id, 1) 
      res.json(true);
    }
  };
   
  var bookList = [{
    name: 'Beginning Node.js by Basarat Ali Syed',
    id: '1'
  }, {
    name: 'Node.JS Web Development by David Herron',
    id: '2'
  }, {
    name: 'Node.js Design Patterns by Mario Casciaro',
    id: '3'
  }, {
    name: 'Getting MEAN with Mongo, Express, Angular, and Node by Simon Holmes',
    id: '4'
  }];
   
  module.exports = books;