var express = require('express');
var router = express.Router();
 
var auth = require('./authenticator.js');
var books = require('./books.js');
var user = require('./users.js');
 
/*
 * Routes that can be accessed by any one
 */
router.post('/login', auth.login);
 
/*
 * Routes that can be accessed only by autheticated users
 */


router.get('/library/v1/books', books.getAll);
router.get('/library/v1/book/:id', books.getOne);
router.post('/library/v1/book/', books.create);
router.put('/library/v1/book/:id', books.update);
router.delete('/library/v1/book/:id', books.delete);
 
/*
 * Routes that can be accessed only by authenticated & authorized users
 */
router.get('/library/v1/admin/users', user.getAll);
router.get('/library/v1/admin/user/:id', user.getOne);
router.post('/library/v1/admin/user/', user.create);
router.put('/library/v1/admin/user/:id', user.update);
router.delete('/library/v1/admin/user/:id', user.delete);
 
module.exports = router;

